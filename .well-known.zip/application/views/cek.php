<!DOCTYPE html>
<html>
<head>
    <title>Data Wemos</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
    <h1>Data dari Wemos</h1>
    <div id="data-container"><?= $value; ?></div>
</body>
</html>
