<!-- navbar start -->
<nav class="navbar navnav navbar-expand-lg">
    <div class="container">
        <div class="navbar-brand fs-2 text-red">Simpeda</div>
        
            <button class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
            <div class="navbar-nav ms-auto">
                <a class="nav-link " aria-current="page" href="<?= base_url('home'); ?>">Home</a>
                <a class="nav-link " href="https://wa.me/085157212192">Contact Us</a>
                <a class="my-auto" href="<?= base_url('auth'); ?>"><button type="button" class="btn btn-primary tombol">Login</button></a>
            </div>
        </div>
    </div>
</nav>
<!-- navbar end -->