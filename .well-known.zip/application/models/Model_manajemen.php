<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_manajemen extends CI_Model
{
    public function getDataManajemen()
    {
        //$query = $this->db->get('manajemen');
        //$this->db->order_by('id', 'desc');
        //$result = $query->result();
        //return $result;
    }
}
